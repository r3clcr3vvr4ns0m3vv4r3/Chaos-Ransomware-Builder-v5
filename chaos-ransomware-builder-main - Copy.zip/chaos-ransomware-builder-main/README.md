### Please only use this on a virtual machine!

## This was not made or owned by any of the members of [shxrks](https://shxrks.wordpress.com).

### Read please!
If you are using this for personal use, I recommend building this with a personal decrypting tool.
I also do not recommend using this software for general use.

## Thank you for reading, and enjoy CRB v4!
